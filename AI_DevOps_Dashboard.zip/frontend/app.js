
document.getElementById('root').innerHTML = '<h1 class="text-2xl font-bold text-blue-600">Welcome to DevOps Dashboard</h1>';
